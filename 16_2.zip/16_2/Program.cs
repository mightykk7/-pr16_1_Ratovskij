﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _16_2
{
    class Program
    {
        //Меняет регистр букв с нижнего в верхний и наоборот
        static string TransformCase(string input)
        {
            return new string(input.Select(c =>
            char.IsLetter(c) ? (char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c)) : c).ToArray());
        }
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Введите массив строк");
                string input = Console.ReadLine();
                string[] arr = input.Split(' ');
                var digits = arr.SelectMany(s => s.Where(char.IsDigit)).ToList();
                Console.WriteLine($"Найдено цифр: {digits.Count}");
                if (digits.Any())
                {
                    Console.WriteLine($"Найдены цифры: {string.Join(" ", digits)}");
                }
                Console.WriteLine("\nЭлементы до первого символа '/':");
                bool slashFound = false;
                foreach (string item in arr)
                {
                    if (item.Contains("/"))
                    {
                        slashFound = true;
                        string partBeforeSlash = item.Substring(0, item.IndexOf("/"));
                        if (!string.IsNullOrEmpty(partBeforeSlash))
                        {
                            Console.WriteLine(partBeforeSlash);
                        }
                        break;
                    }
                    Console.WriteLine(item);
                }
                if (!slashFound)
                {
                    Console.WriteLine("Символ '/' не найден в массиве.");
                }
                Console.WriteLine("\nЭлементы после символа '/' с измененным регистром:");
                List<string> afterSlash = new List<string>();
                bool processing = false;
                foreach (string item in arr)
                {
                    if (!processing && item.Contains("/"))
                    {
                        processing = true;
                        string partAfterSlash = item.Substring(item.IndexOf("/") + 1);
                        if (!string.IsNullOrEmpty(partAfterSlash))
                        {
                            string transformed = TransformCase(partAfterSlash);
                            afterSlash.Add(transformed);
                            Console.WriteLine(transformed);
                        }
                        continue;
                    }
                    if (processing)
                    {
                        string transformed = TransformCase(item);
                        afterSlash.Add(transformed);
                        Console.WriteLine(transformed);
                    }
                }
                if (!processing)
                {
                    Console.WriteLine("Символ '/' не найден, нет элементов для обработки.");
                }
                else
                {
                    File.WriteAllLines("output.txt", afterSlash);
                    Console.WriteLine("\nРезультат записан в файл 'output.txt'");
                }
            }
            catch(Exception)
            {
                Console.WriteLine("Ошибка");
            }
            Console.ReadKey();
        }
    }
}
